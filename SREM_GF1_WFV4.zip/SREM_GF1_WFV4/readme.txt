
******************** SREM_GF1_WFV4_Codes **********************

1. Input data:

	i.	DN data (.tif format)
	ii.	Solar zenith and azimuth angles   (available in metadata file)
	iii. Satellite zenith and azimuth angles  (available in metadata file)
	iv. gain for each band  (available in metadata file)
	v. irradiance (Esun) for each band  (available in metadata file)
	
2. Prepare input text files same as given in the SREMsr folder. 

3. For batch processing, add multiple rows in the text file with respect to available multiple images.
				
4. To run the code, double click and follow the pop-up window instructions. 


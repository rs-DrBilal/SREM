
********************SREM_MODIS_Codes**********************

1. SREM codes for MODIS Bands 1 to 7 are provided separately. 

2. Please note that these codes will work for both Terra and Aqua MODIS.

3. Input data:

	•	TOA reflectance from MOD02 product
	•	Solar and sensor angles (zenith and azimuth) from MOD03 and should have the following bands sequence:

			•	Sensor Zenith Angle
			•	Sensor Azimuth Angle
			•	Solar Zenith Angle
			•	Solar Azimuth Angle

	•	Please make sure that the resolution of both MOD02 and MOD03 is same.
	•	The input data format is ".tif"
				
4. To run the code, double click and follow the pop-up window instructions. 

5. In case, you don't know how to prepare input data (as mentioned above), the following codes for MOD02 and MOD03 are also provided. Please run the codes with the following sequence:

	•	mod02_cal_rad_rep.sav (to get TOA radiance data). Please note that this code takes some time to process mod02 file due to large swath width and high resolution. 
	•	mod03_geoloca_rep.sav (to get solar and sensor angles at 1 km resolution). 
	•	resample_raster_data.sav (to resample mod03 data into 500m resolution same as the resolution of mod02 data).
	•	SREM_MODIS_Bx.sav (to get SREM SR for specific band)


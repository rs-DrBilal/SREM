
******************** SREM_GeoSat_Himawari8_Codes **********************

1. Input data:

	•	TOA reflectance (in this code TOA reflectance = albedo/cos(solzen)) - so, input data should have albedo values (albed = reflectance * cos(solzen))
	•	Solar and sensor angles (zenith and azimuth) 

2. Inptu data structure and format:

	•	Input data should be in '.tif' format.
	•	Each input file should have the following bands sequences (if your data do not have the following bands sequence, then let me know I can modify code according to your data)
			
			•	Albedo Band 1
			•	Albedo Band 2
			•	Albedo Band 3
			•	Albedo Band 4
			•	Albedo Band 5
			•	Albedo Band 6
			•	Satellite Zenith Angle
			•	Satellite Azimuth Angle
			•	Solar Zenith Angle
			•	Solar Azimuth Angle
				
4. To run the code, double click and follow the pop-up window instructions. 

